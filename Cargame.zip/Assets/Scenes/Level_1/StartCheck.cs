using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class StartCheck : MonoBehaviour
{
    List<string> checkPoints;

    public bool CP1 = false;
    public bool CP2 = false;
    int run_times;
    // Start is called before the first frame update
    void Start(){
        print("Start");
        // if (!checkPoints.Contains(checkPointName)) {
        //     checkPoints.Add(checkPointName);
        // }

        // if (checkPoints[0] == )
        
    }
    void OnTriggerEnter(Collider c){
        if (c.tag == "Player"){
            if (CP1 == true&&CP2 == true){
                run_times += 1;
                print(run_times);
                CP1 = false;
                CP2 = false;
            }
        }
    }
}
