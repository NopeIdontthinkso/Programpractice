using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public Rigidbody rb;
    public float movespeed;
    public float rotatespeed;
    public float rotateangle;
    void Update(){
        if (Input.GetKey("a")){
            if (rotateangle>-45){
                rotateangle += -100*Time.deltaTime;
            }
        }
        else if (Input.GetKey("d")){
            if (rotateangle<45){
                rotateangle += 100*Time.deltaTime;
            }
        }
        if (Input.GetKey("w")&&rb.velocity.y>=0){
            transform.localEulerAngles += new Vector3(0,rotateangle*Time.deltaTime*rotatespeed,0);
            if (rb.velocity.magnitude < 1){
                rb.velocity += transform.forward*movespeed;
            }
        }
        // rb.velocity *= 0.9f;
    }
}
