using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ChildrenCheck : MonoBehaviour
{
    public StartCheck STCK;
    void OnTriggerEnter(Collider c){
        if (c.tag == "Player"){
            if (gameObject.name == "CheckPoint1"&&STCK.CP1 == false){
                STCK.CP1 = true;
                print("CP1");
            }
            if (gameObject.name == "CheckPoint2"&&STCK.CP2 == false&&STCK.CP1 == true){
                STCK.CP2 = true;
                print("CP2");
            }
        }
    }
}
